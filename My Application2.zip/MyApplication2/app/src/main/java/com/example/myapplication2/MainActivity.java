package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private RecyclerView myReciclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myReciclerView=(RecyclerView) findViewById(R.id.my_recyler_view);
        myReciclerView.setHasFixedSize(true);

        mLayoutManager=new LinearLayoutManager(this);
        myReciclerView.setLayoutManager(mLayoutManager);
        mAdapter=new MyAdapter (myDataset);
        myReciclerView.setAdapter(mAdapter);

    }
}
